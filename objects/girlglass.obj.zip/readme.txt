-- 3dvia.com   --

The zip file girlglass.obj.zip contains the following files :
- readme.txt
- girlglass.obj


-- Model information --

Model Name : girlglass
Author : Jin Qiao
Publisher : fangao66

You can view this model here :
http://www.3dvia.com/content/DDC702D3E5F7C9DB
More models about this author :
http://www.3dvia.com/fangao66


-- Attached license --

A license is attached to the girlglass model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
