-- 3dvia.com   --

The zip file LinkingStars_002_Octopussy_001b.obj.zip contains the following files :
- readme.txt
- LinkingStars_002_Octopussy_001b.obj


-- Model information --

Model Name : LinkingStars_002_Octopussy_001b
Author : Jonathan Johanson
Publisher : sjoo

You can view this model here :
http://www.3dvia.com/content/D1F5F5C7D9EBFDCF
More models about this author :
http://www.3dvia.com/sjoo


-- Attached license --

A license is attached to the LinkingStars_002_Octopussy_001b model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
