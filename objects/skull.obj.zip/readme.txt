-- 3dvia.com   --

The zip file skull.obj.zip contains the following files :
- readme.txt
- skull.obj
- skull.mtl


-- Model information --

Model Name : skull
Author : Mari01504
Publisher : Mari01504

You can view this model here :
http://www.3dvia.com/content/8BDF778193A5B789
More models about this author :
http://www.3dvia.com/Mari01504


-- Attached license --

A license is attached to the skull model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
