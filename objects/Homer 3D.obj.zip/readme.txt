-- 3dvia.com   --

The zip file Homer 3D.obj.zip contains the following files :
- readme.txt
- Homer 3D.obj


-- Model information --

Model Name : Homer 3D
Author : WiZiX
Publisher : WiZiX

You can view this model here :
http://www.3dvia.com/content/1C5B7E122436081A
More models about this author :
http://www.3dvia.com/WiZiX


-- Attached license --

A license is attached to the Homer 3D model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
