-- 3dvia.com   --

The zip file jade2.obj.zip contains the following files :
- readme.txt
- jade2.obj
- Thorax_Top_JacketColor.tga
- Thorax_BellybuttonColor.tga
- Thorax_BellybuttonBump.tga
- jade2.mtl
- Head_Hair_Hair5Color.tga
- EyeR_EyelashR_EyelashRColor.tga
- EyeL_EyelashL_EyelashLColor.tga


-- Model information --

Model Name : jade2
Author : Quidam
Publisher : wismo

You can view this model here :
http://www.3dvia.com/content/606B0456687A4C5E
More models about this author :
http://www.3dvia.com/wismo


-- Attached license --

A license is attached to the jade2 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
