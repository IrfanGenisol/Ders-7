-- 3dvia.com   --

The zip file skirtlong2.obj.zip contains the following files :
- readme.txt
- skirtlong2.obj


-- Model information --

Model Name : skirtlong2
Author : Jin Qiao
Publisher : fangao66

You can view this model here :
http://www.3dvia.com/content/9D874193A5B7899B
More models about this author :
http://www.3dvia.com/fangao66


-- Attached license --

A license is attached to the skirtlong2 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
