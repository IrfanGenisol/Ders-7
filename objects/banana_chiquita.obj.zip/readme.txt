-- 3dvia.com   --

The zip file banana_chiquita.obj.zip contains the following files :
- readme.txt
- banana_chiquita.obj
- banana_low_res_topo_cleanImage1.bmp
- banana_chiquita.mtl


-- Model information --

Model Name : banana_chiquita
Author : VIUscan (Handyscan 3D)
Publisher : Creaform

You can view this model here :
http://www.3dvia.com/content/D0C9F7C6D8EAFCCE
More models about this author :
http://www.3dvia.com/Creaform


-- Attached license --

A license is attached to the banana_chiquita model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
