-- 3dvia.com   --

The zip file lg_cocacola_can.obj.zip contains the following files :
- readme.txt
- lg_cocacola_can.obj
- lg_cocacola_can_GEN.mtl
- lg_cocacola_can.1_OUT.png
- CanTop1.png


-- Model information --

Model Name : Soda Can
Author : gsmith
Publisher : gsmith

You can view this model here :
http://www.3dvia.com/content/278C081D2F011325
More models about this author :
http://www.3dvia.com/gsmith


-- Attached license --

A license is attached to the Soda Can model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial 2.5
Detailed license : http://creativecommons.org/licenses/by-nc/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
